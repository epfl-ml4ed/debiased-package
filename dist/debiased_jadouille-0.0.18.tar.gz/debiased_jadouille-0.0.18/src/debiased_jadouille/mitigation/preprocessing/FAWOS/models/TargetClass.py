
class TargetClass:

    def __init__(self,
                 name: str,
                 positive_class: str,
                 negative_class: str):

        self.name = name
        self.positive_class = positive_class
        self.negative_class = negative_class