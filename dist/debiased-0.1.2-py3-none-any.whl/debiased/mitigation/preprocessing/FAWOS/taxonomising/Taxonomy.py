from enum import Enum


class Taxonomy(Enum):
    SAFE = "Safe"
    BORDERLINE = "Bordeline"
    RARE = "Rare"
    OUTLIER = "Outlier"